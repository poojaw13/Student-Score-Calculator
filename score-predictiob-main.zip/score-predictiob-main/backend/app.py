from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np

app = Flask(__name__)
CORS(app)  # Enable CORS for React frontend

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        attendance = float(data["attendance"])
        assignments = float(data["assignments"])
        exams = float(data["exams"])

        # Example prediction model (replace with ML model later)
        predicted_score = round(0.2 * attendance + 0.3 * assignments + 0.5 * exams, 2)

        return jsonify({"predicted_score": predicted_score})

    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)
