import React, { useState } from "react";
import "./index.css"; // Import global styles

const Predictor = () => {
  const [attendance, setAttendance] = useState("");
  const [assignments, setAssignments] = useState("");
  const [exams, setExams] = useState("");
  const [prediction, setPrediction] = useState(null);

  const handlePredict = async () => {
    if (!attendance || !assignments || !exams) {
      alert("Please fill in all fields!");
      return;
    }

    try {
      const response = await fetch("http://127.0.0.1:5000/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          attendance: parseFloat(attendance),
          assignments: parseFloat(assignments),
          exams: parseFloat(exams),
        }),
      });

      const data = await response.json();
      setPrediction(data.predicted_score || "Error predicting score");
    } catch (error) {
      console.error("Prediction error:", error);
      setPrediction("Error in prediction");
    }
  };

  return (
    <div className="container">
      <h1>Student Performance Predictor</h1>

      <div className="input-group">
        <label>Attendance (%)</label>
        <input
          type="number"
          value={attendance}
          onChange={(e) => setAttendance(e.target.value)}
          placeholder="Enter attendance (e.g., 80)"
        />
      </div>

      <div className="input-group">
        <label>Assignments Score</label>
        <input
          type="number"
          value={assignments}
          onChange={(e) => setAssignments(e.target.value)}
          placeholder="Enter assignment score (e.g., 70)"
        />
      </div>

      <div className="input-group">
        <label>Exams Score</label>
        <input
          type="number"
          value={exams}
          onChange={(e) => setExams(e.target.value)}
          placeholder="Enter exam score (e.g., 85)"
        />
      </div>

      <button onClick={handlePredict}>Predict Score</button>

      {prediction !== null && <div className="result">Predicted Score: {prediction}</div>}
    </div>
  );
};

export default Predictor;
